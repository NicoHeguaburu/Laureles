// CONSTRUCTOR
class Productos {
    constructor(articulo, precio, color) {
        this.articulo = articulo;
        this.precio = parseFloat(precio);
        this.color = color;
    }
}
const listaProductos = [];
listaProductos.push(new Productos("mesita", "2000", "madera"));
listaProductos.push(new Productos("cuadro", "600", "blanco"));
listaProductos.push(new Productos("bandeja", "200", "gris"));
listaProductos.push(new Productos("centro de mesa", "850", "marron"));
// BUSQUEDA EN EL ARRAY
let busqueda = prompt("busca entre mesita, cuadro, bandeja y centro de mesa y ve los resultados por consola");

let newArreglo = listaProductos.filter(function(objeto) {
    return (objeto.articulo == busqueda);
})

console.log(newArreglo);